<?php include("../config.php");
if($_SESSION['role']!='admin'){ header("Location: ../login.php"); }
include("layout.php"); ?>
<div style="margin-left:210px;padding:20px;">
<h2>Users</h2>
<table border="1" cellpadding="10">
<tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Action</th></tr>
<?php $res=$conn->query("SELECT * FROM users");
while($r=$res->fetch_assoc()){ ?>
<tr>
<td><?= $r['id'] ?></td>
<td><?= $r['name'] ?></td>
<td><?= $r['email'] ?></td>
<td><?= $r['role'] ?></td>
<td>
<a href="edit_user.php?id=<?= $r['id'] ?>">Edit</a> |
<a href="delete_user.php?id=<?= $r['id'] ?>" onclick="return confirm('Delete?')">Delete</a>
</td>
</tr>
<?php } ?>
</table>
</div>