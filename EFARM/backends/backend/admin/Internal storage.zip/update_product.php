<?php
include "../config/db.php";

$id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];

$query = "UPDATE products SET name='$name', price='$price' WHERE id='$id'";

if (mysqli_query($conn, $query)) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error"]);
}
?>